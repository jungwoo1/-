package com.example.chaosbicycle;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MapActivity extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private static final int PERMISSIONS_REQUEST_ACCESS_CALL_PHONE = 2;

    private List<Model__station> checkAlready;

    private MapView mapView;
    private Boolean isCurrentCheck = false;

    static final String LOG_TAG = PubSubMqtt.class.getCanonicalName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        Intent intent = getIntent();
        String state = intent.getStringExtra("state");

        Log.i("chaos",state);

        mapView = new MapView(this);

        ViewGroup mapViewContainer = (ViewGroup) findViewById(R.id.map_view);
        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(37.527122, 127.028717);
        mapView.setMapCenterPoint(mapPoint, true);
        //true면 앱 실행 시 애니메이션 효과가 나오고 false면 애니메이션이 나오지않음.
        mapViewContainer.addView(mapView);

        Log.i("chaos","getStation start");
        getStation(state);

    }

    //Lambda 사용해서 db연결
    public void getStation(String state) {
        //Retrofit 호출
        Model__station modelCheckAlready = new Model__station();
        Call<List<Model__station>> call = RetrofitClient.getApiService().getStationData(state);
        call.enqueue(new Callback<List<Model__station>>() {
            @Override
            public void onResponse(Call<List<Model__station>> call, Response<List<Model__station>> response) {
                if(!response.isSuccessful()){
                    Log.e("연결이 비정상적 : ", "error code : " + response.code());
                    return;
                }
                checkAlready = response.body();
                Log.d("연결이 성공적 : ", response.body().toString());
                createMap();
            }
            @Override
            public void onFailure(Call<List<Model__station>> call, Throwable t) {
                Log.e("연결실패", t.getMessage());
            }
        });
    }

    //지도 만들기 함수 : 보관소 마커 표시
    public void createMap(){
        int i = 0;
        Log.d("createMap yejin", String.valueOf(checkAlready));

        for(Model__station station : checkAlready){
            MapPOIItem StationMarker = new MapPOIItem();
            StationMarker.setItemName(station.getStationName());
            StationMarker.setTag(i);
            StationMarker.setMapPoint(MapPoint.mapPointWithGeoCoord(Double.parseDouble(station.getStationLatitude()),Double.parseDouble(station.getStationLongitude())));

            if(station.getPredict() > station.getRackTotCnt()){
                // 기본으로 제공하는 BluePin 마커 모양.
                StationMarker.setMarkerType(MapPOIItem.MarkerType.YellowPin);
            }else if(station.getPredict() > station.getRackTotCnt() * 0.7){
                // 기본으로 제공하는 BluePin 마커 모양.
                StationMarker.setMarkerType(MapPOIItem.MarkerType.BluePin);
            }else{
                StationMarker.setMarkerType(MapPOIItem.MarkerType.RedPin);
            }

            // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.
//            StationMarker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin);
            /* Custom Marker XML 설정 구문 */
            View mView = getLayoutInflater().inflate(R.layout.activity_custommaker, null);
            ((ImageView) mView.findViewById(R.id.marker_image)).setImageResource(R.drawable.bike); /* Maker Image 변경 해주는 구문 */
            ((TextView) mView.findViewById(R.id.main_title)).setText(station.getStationName()); /* Maker Text 변경 해주는 구문 */
            ((TextView) mView.findViewById(R.id.sub_title)).setText("현재 사용가능 대수 : "+station.getParkingBikeTotCnt()+"/"+station.getRackTotCnt()+"("+station.getShared()+"%)"); /* Maker 장소 변경 해주는 구문 */
            ((TextView) mView.findViewById(R.id.sub_title2)).setText("1시간 후 사용가능 : "+station.getPredict()+"대 예상"); /* Maker 장소 변경 해주는 구문 */
            StationMarker.setCustomCalloutBalloon(mView);

            mapView.addPOIItem(StationMarker);
            i++;
        }

        //재배치 필요한 보관소 테이블 생성 함수 실행
        createStationTable();

    }

    //재배치 필요한 보관소 테이블 생성 함수
    public void createStationTable(){
        ListView listview = (ListView)findViewById(R.id.stationTable);

        //데이터를 저장하게 되는 리스트
        List<String> list = new ArrayList<>();

        //리스트뷰와 리스트를 연결하기 위해 사용되는 어댑터
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, list);

        //리스트뷰의 어댑터를 지정해준다.
        listview.setAdapter(adapter);


        //리스트뷰의 아이템을 클릭시 해당 아이템의 문자열을 가져오기 위한 처리
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView,
                                    View view, int position, long id) {
                //클릭한 아이템의 문자열을 가져옴
                String selected_item = (String)adapterView.getItemAtPosition(position);
                Log.i("yejin",selected_item);
            }
        });


        //리스트뷰에 보여질 아이템을 추가
        Iterator iterator = checkAlready.iterator();
        while(iterator.hasNext()){
            Model__station stationData = ((Model__station) iterator.next());
            list.add(stationData.getStationName()+"\n 현재"+stationData.getParkingBikeTotCnt()+"대 사용가능"+"\n"+stationData.getPredict()+"대 사용가능 예상");
        }

    }

    //현재 위치로 지도 이동 함수
    public void goToCurrentLocation(View view) {
        if(isCurrentCheck){
            mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOff);
            mapView.setShowCurrentLocationMarker(false);
            ((TextView)view.findViewById(R.id.checkCurrentLocation)).setText("현재위치로 이동");
            isCurrentCheck = false;
        }else{
            mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithHeading);
            ((TextView)view.findViewById(R.id.checkCurrentLocation)).setText("현재위치 취소");
            isCurrentCheck = true;
        }

    }
}