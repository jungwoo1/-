import sys

import logging

import pymysql


def lambda_handler(event, context):
    stateMap = {
        "jongno": "종로구","eunpyeong":"은평구",
        "gangseo":"강서구","jung":"중구",
        "guro":"구로구","seongdong":"성동구",
        "gwanak":"관악구","gwangjin":"광진구",
        "yeongdeungpo":"영등포구","yongsan":"용산구",
        "geumcheon":"금천구","dongdaemun":"동대문구",
        "yangcheon":"양천구","seodaemun":"서대문구",
        "songpa":"송파구","mapo":"마포구",
        "gangnam":"강남구","gangbuk":"강북구",
        "seocho":"서초구","nowon":"노원구",
        "dongjak":"동작구","jungnang":"중랑구",
        "gangdong":"강동구","dobong":"도봉구",
        "seongbuk":"성북구",
    };
    
    params_arry = event['params']
    print("params_arry",params_arry);
    path_arry = params_arry['path']
    print("path_arry",path_arry);
    state = path_arry['state_name']
    
    state_kor = stateMap[state];
    print("state_kor",state_kor);
    conn = pymysql.connect(host="db-bigdata-bicycle.cynn0zdjjttk.us-east-1.rds.amazonaws.com", user="admin", password="chaosproject", db="chaos", charset='utf8')

    curs = conn.cursor()

    get_sql = "select combine.*, ifnull(result,0)+parkingBikeTotCnt as predict"
    get_sql += " from (select rackTotCnt,stationNumber,stationName,parkingBikeTotCnt,shared,stationLongitude,stationLatitude"
    get_sql += " from everyOneHourAPI e,localCopy l where e.stationId=l.stationId and l.state='"+state_kor+"') as combine"
    get_sql += " LEFT OUTER JOIN bigdata b ON combine.stationNumber = b.stationNumber order by predict ASC"
    
    curs.execute(get_sql)
    
    col_headers = [x[0] for x in curs.description]
    print(col_headers)

    rows = curs.fetchall()

    json_data = []
    for result in rows:
        json_data.append(dict(zip(col_headers, result)))

    conn.commit()
    conn.close()

    return json_data


