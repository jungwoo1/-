import pymysql, os
from bs4 import BeautifulSoup
import urllib.request
import urllib.request as req
import json

def lambda_handler(event, context):    
    pymysql.install_as_MySQLdb()

    mysql_conn = pymysql.connect(host="호스트주소",\
        user="호스트ID", password='패스워드', db="DB명", charset='utf8')
    mysql_cursor = mysql_conn.cursor()

    # DB 테이블 DROP
    drop_OneHoursql = "DROP TABLE IF EXISTS `everyOneHourAPI`"
    mysql_cursor.execute(drop_OneHoursql)
    
    # DB 테이블 & 컬럼 생성
    create_sql = """CREATE TABLE IF NOT EXiSTS `everyOneHourAPI` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `rackTotCnt` int(11),
    `stationName` varchar(255),
    `parkingBikeTotCnt` int(11),
    `shared` int(11),
    `stationId` varchar(255)
        )"""
    
    mysql_cursor.execute(create_sql)
    
    #서울 열린데이터 광장에서 openapi를 사용해 따릉이의 실시간 대여정보 받아오기
    client_key = '6165464657616b6132337959516847'
    num = 1000
    bike_url = 'http://openapi.seoul.go.kr:8088/' + client_key + '/json/bikeList/1/' + str(num)

    request = urllib.request.Request(bike_url)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()

    dataList = ''
    if(rescode == 200):
        response_body = response.read()
        dataList = json.loads(response_body)

    else:
        print('오류 코드 : ' + rescode)

    for i in range(len(dataList['rentBikeStatus']['row'])):
        rackTotCnt = int(dataList['rentBikeStatus']['row'][i]['rackTotCnt'])
        stationName = dataList['rentBikeStatus']['row'][i]['stationName']
        parkingBikeTotCnt = int(dataList['rentBikeStatus']['row'][i]['parkingBikeTotCnt'])
        shared = int(dataList['rentBikeStatus']['row'][i]['shared'])
        stationLatitude = dataList['rentBikeStatus']['row'][i]['stationLatitude']
        stationLongitude = dataList['rentBikeStatus']['row'][i]['stationLongitude']
        stationId = dataList['rentBikeStatus']['row'][i]['stationId']

        # print(rackTotCnt, stationName, parkingBikeTotCnt, shared, stationLatitude, stationLongitude, stationId)

        # REPLACE 다시 시도해봐야함
        update_sql = """REPLACE INTO `everyOneHourAPI` 
        (`rackTotCnt`, `stationName`, `parkingBikeTotCnt`, `shared`, `stationId`) 
        VALUES (%s, %s, %s, %s, %s)"""

        mysql_cursor.execute(update_sql, (rackTotCnt, stationName, parkingBikeTotCnt, shared, stationId))

    client_key = '6165464657616b6132337959516847'
    num = 2000
    bike_url = 'http://openapi.seoul.go.kr:8088/' + client_key + '/json/bikeList/1001/' + str(num)

    request = urllib.request.Request(bike_url)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()

    dataList = ''
    if(rescode == 200):
        response_body = response.read()
        dataList = json.loads(response_body)

    else:
        print('오류 코드 : ' + rescode)

    for i in range(len(dataList['rentBikeStatus']['row'])):
        rackTotCnt = int(dataList['rentBikeStatus']['row'][i]['rackTotCnt'])
        stationName = dataList['rentBikeStatus']['row'][i]['stationName']
        parkingBikeTotCnt = int(dataList['rentBikeStatus']['row'][i]['parkingBikeTotCnt'])
        shared = int(dataList['rentBikeStatus']['row'][i]['shared'])
        stationLatitude = dataList['rentBikeStatus']['row'][i]['stationLatitude']
        stationLongitude = dataList['rentBikeStatus']['row'][i]['stationLongitude']
        stationId = dataList['rentBikeStatus']['row'][i]['stationId']


        # REPLACE 다시 시도해봐야함
        update_sql = """REPLACE INTO `everyOneHourAPI` 
        (`rackTotCnt`, `stationName`, `parkingBikeTotCnt`, `shared`, `stationId`) 
        VALUES (%s, %s, %s, %s, %s)"""

        mysql_cursor.execute(update_sql, (rackTotCnt, stationName, parkingBikeTotCnt, shared, stationId))

    client_key = '6165464657616b6132337959516847'
    num = 2083
    bike_url = 'http://openapi.seoul.go.kr:8088/' + client_key + '/json/bikeList/2001/' + str(num)

    request = urllib.request.Request(bike_url)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()

    dataList = ''
    if(rescode == 200):
        response_body = response.read()
        dataList = json.loads(response_body)

    else:
        print('오류 코드 : ' + rescode)

    for i in range(len(dataList['rentBikeStatus']['row'])):
        rackTotCnt = int(dataList['rentBikeStatus']['row'][i]['rackTotCnt'])
        stationName = dataList['rentBikeStatus']['row'][i]['stationName']
        parkingBikeTotCnt = int(dataList['rentBikeStatus']['row'][i]['parkingBikeTotCnt'])
        shared = int(dataList['rentBikeStatus']['row'][i]['shared'])
        stationLatitude = dataList['rentBikeStatus']['row'][i]['stationLatitude']
        stationLongitude = dataList['rentBikeStatus']['row'][i]['stationLongitude']
        stationId = dataList['rentBikeStatus']['row'][i]['stationId']


        # REPLACE 다시 시도해봐야함
        update_sql = """REPLACE INTO `everyOneHourAPI` 
        (`rackTotCnt`, `stationName`, `parkingBikeTotCnt`, `shared`, `stationId`) 
        VALUES (%s, %s, %s, %s, %s)"""

        mysql_cursor.execute(update_sql, (rackTotCnt, stationName, parkingBikeTotCnt, shared, stationId))

    mysql_conn.commit()
    mysql_conn.close()