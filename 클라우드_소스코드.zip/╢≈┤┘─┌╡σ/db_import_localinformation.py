import pymysql
from bs4 import BeautifulSoup
import urllib.request
import urllib.request as req
import json


pymysql.install_as_MySQLdb()

mysql_conn = pymysql.connect(host="호스트주소",\
    user="호스트ID", password='패스워드', db="DB명", charset='utf8')
mysql_cursor = mysql_conn.cursor()



drop_localInformationsql = "DROP TABLE IF EXISTS `localInformation`"
mysql_cursor.execute(drop_localInformationsql)

# DB 테이블 & 컬럼 생성

create_sql_local = """CREATE TABLE IF NOT EXISTS `localInformation` (
    `local_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `stationLatitude` varchar(255),
    `stationLongitude` varchar(255),
    `stationId` varchar(255)
)"""

mysql_cursor.execute(create_sql_local)


#서울 열린데이터 광장에서 openapi를 사용해 따릉이의 실시간 대여정보 받아오기
client_key = '6165464657616b6132337959516847'
num = 1000
bike_url = 'http://openapi.seoul.go.kr:8088/' + client_key + '/json/bikeList/1/' + str(num)

request = urllib.request.Request(bike_url)
response = urllib.request.urlopen(request)
rescode = response.getcode()

dataList = ''
if(rescode == 200):
    response_body = response.read()
    dataList = json.loads(response_body)

else:
    print('오류 코드 : ' + rescode)


for i in range(len(dataList['rentBikeStatus']['row'])):
    stationLatitude = dataList['rentBikeStatus']['row'][i]['stationLatitude']
    stationLongitude = dataList['rentBikeStatus']['row'][i]['stationLongitude']
    stationId = dataList['rentBikeStatus']['row'][i]['stationId']


    localInformation = """REPLACE INTO `localInformation` 
    (`stationLatitude`, `stationLongitude`, `stationId`) 
    VALUES (%s, %s, %s)"""

    # mysql_cursor.execute(update_sql, (rackTotCnt, stationName, parkingBikeTotCnt, shared, stationId))
    mysql_cursor.execute(localInformation, (stationLatitude, stationLongitude, stationId))


# DB 데이터 임포트 & 업데이트 - 시도 중
# update_sql = """INSERT INTO `everyOneHourAPI` 
# (`rackTotCnt`, `stationName`, `parkingBikeTotCnt`, `shared`, `stationLatitude`, `stationLongitude`, `stationId`) 
# VALUES (%s, %s, %s, %s, %s, %s, %s) 
# ON DUPLICATE KEY UPDATE `rackTotCnt`=%s, `stationName`=%s, `parkingBikeTotCnt`=%s, `shared`=%s, `stationLatitude`=%s, `stationLongitude`=%s, `stationId`=%s"""

# mysql_cursor.execute(update_sql, (rackTotCnt, stationName, parkingBikeTotCnt, shared, stationLatitude, stationLongitude, stationId, \
#     rackTotCnt, stationName, parkingBikeTotCnt, shared, stationLatitude, stationLongitude, stationId))

client_key = '6165464657616b6132337959516847'
num = 2000
bike_url = 'http://openapi.seoul.go.kr:8088/' + client_key + '/json/bikeList/1001/' + str(num)

request = urllib.request.Request(bike_url)
response = urllib.request.urlopen(request)
rescode = response.getcode()

dataList = ''
if(rescode == 200):
    response_body = response.read()
    dataList = json.loads(response_body)

else:
    print('오류 코드 : ' + rescode)


for i in range(len(dataList['rentBikeStatus']['row'])):
    stationLatitude = dataList['rentBikeStatus']['row'][i]['stationLatitude']
    stationLongitude = dataList['rentBikeStatus']['row'][i]['stationLongitude']
    stationId = dataList['rentBikeStatus']['row'][i]['stationId']


    localInformation = """REPLACE INTO `localInformation` 
    (`stationLatitude`, `stationLongitude`, `stationId`) 
    VALUES (%s, %s, %s)"""


    mysql_cursor.execute(localInformation, (stationLatitude, stationLongitude, stationId))


client_key = '6165464657616b6132337959516847'
num = 2083
bike_url = 'http://openapi.seoul.go.kr:8088/' + client_key + '/json/bikeList/2001/' + str(num)

request = urllib.request.Request(bike_url)
response = urllib.request.urlopen(request)
rescode = response.getcode()

dataList = ''
if(rescode == 200):
    response_body = response.read()
    dataList = json.loads(response_body)

else:
    print('오류 코드 : ' + rescode)


for i in range(len(dataList['rentBikeStatus']['row'])):
    stationLatitude = dataList['rentBikeStatus']['row'][i]['stationLatitude']
    stationLongitude = dataList['rentBikeStatus']['row'][i]['stationLongitude']
    stationId = dataList['rentBikeStatus']['row'][i]['stationId']


    localInformation = """REPLACE INTO `localInformation` 
    (`stationLatitude`, `stationLongitude`, `stationId`) 
    VALUES (%s, %s, %s)"""

    # mysql_cursor.execute(update_sql, (rackTotCnt, stationName, parkingBikeTotCnt, shared, stationId))
    mysql_cursor.execute(localInformation, (stationLatitude, stationLongitude, stationId))

mysql_conn.commit()
mysql_conn.close()