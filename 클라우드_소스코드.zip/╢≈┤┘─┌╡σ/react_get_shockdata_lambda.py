import pymysql

def lambda_handler(event, context):
    pymysql.install_as_MySQLdb()
    mysql_conn = pymysql.connect(host="db-bigdata-bicycle.cynn0zdjjttk.us-east-1.rds.amazonaws.com",\
    user="admin", password='chaosproject', db="chaos", charset='utf8')

    mysql_cursor = mysql_conn.cursor()

    # get_sql = "SELECT * FROM `everyOneHourAPI`"
    get_sql = "SELECT * FROM shockData"

    mysql_cursor.execute(get_sql)
    col_headers = [x[0] for x in mysql_cursor.description]
    print(col_headers)

    rows = mysql_cursor.fetchall()

    json_data = []
    for result in rows:
        json_data.append(dict(zip(col_headers, result)))

    mysql_conn.commit()
    mysql_conn.close()

    return json_data
