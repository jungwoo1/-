import pymysql

def lambda_handler(event, context):
    pymysql.install_as_MySQLdb()
    mysql_conn = pymysql.connect(host="호스트주소",\
    user="호스트ID", password='패스워드', db="DB명", charset='utf8')

    mysql_cursor = mysql_conn.cursor()

    get_sql = "SELECT * FROM `localInformation`"

    mysql_cursor.execute(get_sql)
    col_headers = [x[0] for x in mysql_cursor.description]
    print(col_headers)

    rows = mysql_cursor.fetchall()

    json_data = []
    for result in rows:
        json_data.append(dict(zip(col_headers, result)))

    mysql_conn.commit()
    mysql_conn.close()

    return json_data