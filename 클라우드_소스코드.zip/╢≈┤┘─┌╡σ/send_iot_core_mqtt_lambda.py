from __future__ import print_function
  
import json
import boto3
  
print('Loading function')
  
def lambda_handler(event, context):
  
    # Print the parsed JSON message to the console. You can view this text in the Monitoring tab in the AWS Lambda console or in the Amazon CloudWatch Logs console.
    print('Received: IotCore_lambda')
  
    client = boto3.client('iot-data', region_name='us-east-1')
  
    # Change topic, qos and payload
    response = client.publish(
               topic='test/topic',
               qos=0,
               payload=json.dumps({"alert":"True"})
    )
  
    return "Send IotCore_lambda!"