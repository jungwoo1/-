import pymysql

def lambda_handler(event, context):
    pymysql.install_as_MySQLdb()
    mysql_conn = pymysql.connect(host="db-bigdata-bicycle.cynn0zdjjttk.us-east-1.rds.amazonaws.com",\
    user="admin", password='chaosproject', db="chaos", charset='utf8')

    # state = event['state']
    # print("state:",state)

    mysql_cursor = mysql_conn.cursor()

    # get_sql = "SELECT * FROM `localInformation`"
    # get_sql = "select stationLatitude,stationLongitude,stationName,parkingBikeTotCnt,shared,rackTotCnt,state,localInformation.stationId as stationId from localInformation,everyOneHourAPI where localInformation.stationId = everyOneHourAPI.stationId order by shared DESC"
    get_sql = "select combine.*, ifnull(result,0)+parkingBikeTotCnt as predict "
    get_sql += "from (select rackTotCnt,stationNumber,stationName,parkingBikeTotCnt,shared,e.stationId as stationId,stationLongitude,stationLatitude,state "
    get_sql += "from everyOneHourAPI e,localCopy l where e.stationId=l.stationId) as combine "
    get_sql += "LEFT OUTER JOIN bigdata b ON combine.stationNumber = b.stationNumber order by predict DESC"
    mysql_cursor.execute(get_sql)
    
    # mysql_cursor.execute("select stationLatitude,stationLongitude,stationName,parkingBikeTotCnt,shared,rackTotCnt from localInformation,everyOneHourAPI where localInformation.stationId = everyOneHourAPI.stationId and state=%s order by parkingBikeTotCnt DESC",state)
    
    col_headers = [x[0] for x in mysql_cursor.description]
    print(col_headers)

    rows = mysql_cursor.fetchall()

    json_data = []
    for result in rows:
        json_data.append(dict(zip(col_headers, result)))

    mysql_conn.commit()
    mysql_conn.close()

    return json_data
