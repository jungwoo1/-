# How-to-use-NEO-_6M-GPS-module-with-Arduino
This is basic example of using a small gps(neo_6m) module with Arduino. This GPS module has 4 pins GND,TX,RX,VCC. For more about gps go to this link https://youtu.be/yKtngUPFJbU
